export enum AlignmentTypes {
  left = 'left' as any,
  center = 'center' as any,
  right = 'right' as any
}
