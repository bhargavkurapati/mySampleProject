export enum ShowTypes {
  all = 'all' as any,
  focus = 'focus' as any,
  mouseover = 'mouseover' as any
}
