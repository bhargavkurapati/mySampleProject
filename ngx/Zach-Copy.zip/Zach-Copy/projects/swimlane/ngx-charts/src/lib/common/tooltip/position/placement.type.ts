export enum PlacementTypes {
  top = 'top' as any,
  bottom = 'bottom' as any,
  left = 'left' as any,
  right = 'right' as any
}
