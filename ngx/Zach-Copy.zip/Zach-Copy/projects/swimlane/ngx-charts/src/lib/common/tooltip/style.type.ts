export enum StyleTypes {
  popover = 'popover' as any,
  tooltip = 'tooltip' as any
}
