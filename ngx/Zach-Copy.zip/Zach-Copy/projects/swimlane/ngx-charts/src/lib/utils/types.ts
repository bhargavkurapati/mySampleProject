export function isDate(value) {
  return toString.call(value) === '[object Date]';
}

export function isNumber(value) {
  return typeof value === 'number';
}
