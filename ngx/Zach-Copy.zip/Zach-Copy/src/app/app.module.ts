import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
 import { NvD3Module } from 'ng2-nvd3';
 import 'nvd3';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { HeatMapsComponent } from './heat-maps/heat-maps.component';
import { CustomChartsComponent } from './custom-charts/custom-charts.component';
import { PieChartGridComponent } from './pie-chart-grid/pie-chart-grid.component';
import { PieChartComponent } from './pie-chart/pie-chart.component';
import { PieChartAdvancedComponent } from './pie-chart-advanced/pie-chart-advanced.component';
import { AreaChartsComponent } from './area-charts/area-charts.component';
import { AreaChartsStackedComponent } from './area-charts-stacked/area-charts-stacked.component';
import { NormlizdAreaChartComponent } from './normlizd-area-chart/normlizd-area-chart.component';
import { BubleChartComponent } from './buble-chart/buble-chart.component';
import { TreeChartComponent } from './tree-chart/tree-chart.component';
import { LinearGaugeChartComponent } from './linear-gauge-chart/linear-gauge-chart.component';
import { GuageChartComponent } from './guage-chart/guage-chart.component';
import { PolarChartComponent } from './polar-chart/polar-chart.component';
import { NumberChartComponent } from './number-chart/number-chart.component';
import { BarChartHorizontalComponent } from './bar-chart-horizontal/bar-chart-horizontal.component';
import { BarChartHorizontalGroupedComponent } from './bar-chart-horizontal-grouped/bar-chart-horizontal-grouped.component';
import { ComboChartsComponent } from './combo-charts/combo-charts.component';
import { HeatChartCalenderComponent } from './heat-chart-calender/heat-chart-calender.component';
// import { DynamicFormsComponent } from './dynamic-forms/dynamic-forms.component';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import {Nvd3Component} from './NVD3-charts/nvd3/nvd3.component';
import { Nvd3SineCosComponent } from './NVD3-charts/nvd3-sine-cos/nvd3-sine-cos.component';
import { DonutchartComponent } from './donutchart/donutchart.component'; 



@NgModule({
  declarations: [
    AppComponent,
    HeatMapsComponent,
    CustomChartsComponent,
    PieChartGridComponent,
    PieChartComponent,
    PieChartAdvancedComponent,
    AreaChartsComponent,
    AreaChartsStackedComponent,
    NormlizdAreaChartComponent,
    BubleChartComponent,
    TreeChartComponent,
    LinearGaugeChartComponent,
    GuageChartComponent,
    PolarChartComponent,
    NumberChartComponent,
    BarChartHorizontalComponent,
    BarChartHorizontalGroupedComponent,
    ComboChartsComponent,
    HeatChartCalenderComponent,
    Nvd3Component,
    Nvd3SineCosComponent,
    DonutchartComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgxChartsModule,
    BrowserAnimationsModule,
    FormsModule, 
    ReactiveFormsModule,
    NvD3Module    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }