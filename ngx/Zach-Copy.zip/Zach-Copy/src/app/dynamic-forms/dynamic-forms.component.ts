import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators }  from '@angular/forms'
import { FormGroup, FormControl } from '@angular/forms';
import {FormArray} from '@angular/forms'

@Component({
  selector: 'app-dynamic-forms',
  templateUrl: './dynamic-forms.component.html',
  styleUrls: ['./dynamic-forms.component.scss']
})
export class DynamicFormsComponent  {
  
 
}
